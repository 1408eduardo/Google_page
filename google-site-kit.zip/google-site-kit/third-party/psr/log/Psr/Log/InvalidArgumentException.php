<?php

namespace Google\Site_Kit_Dependencies\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
